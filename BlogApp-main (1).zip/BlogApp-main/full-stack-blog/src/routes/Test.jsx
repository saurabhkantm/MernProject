import Image from "../components/Image";

const Test = () => {
  return (
    <div className="h-screen w-screen">
      <h1>testing page!</h1>
      <Image path={`adminPortal.png`}></Image>
    </div>
  );
};

export default Test;
